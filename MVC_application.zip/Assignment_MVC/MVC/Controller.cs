﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.Model;
using Assignment_MVC.Views;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_MVC.MVC
{
    //class controller: has a list of views and updates them when required
    public class Controller
    {
        /// <summary>
        /// List of views
        /// </summary>
        List<IView> _views = new List<IView>();
        #region Controller
        public Controller()
        {
            
        }
        #endregion 
        /// <summary>
        /// adding  a view
        /// </summary>
        /// <param name="view"></param>
        public void AddView(IView view)
        {
            _views.Add(view);
        }

        /// <summary>
        /// remove a view
        /// </summary>
        /// <param name="view"></param>
        public void RemoveView(IView view)
        {
            _views.Remove(view);
        }
        /// <summary>
        /// update view
        /// </summary>
        public void UpdateViews()
        {
            foreach( IView iw in _views)
            {
                iw.UpdateView();
            }
        }
    }
}
