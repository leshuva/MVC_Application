﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.MVC;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace Assignment_MVC.Model
{
    //class Model -connected with views and tells controller to update all views if required
    public class Model
    {
        BinaryFormatter _binFormatter = new BinaryFormatter();
        private static string _fileName= "c:\\Temp\\data.dat";
        private static Thread _writeToBinary;
        public  bool _isRunning; 
        //public static bool IsRunning { get { return _isRunning; } }
        private List<Dot> _dots = new List<Dot>();

        public Controller _cont;

        public List<Dot> Dots
        {
            get
            {
                return _dots;
            }
        }
       //Constructor
        public Model(Controller controller)
        {

            _cont = controller;
            if (File.Exists("c:\\Temp\\data.dat"))
            {
                Deserialize();
            }
            else
            {
                CreateSomeDots();
            }
            _isRunning = true;
            ThreadWorking();

        }

        /// <summary>
        /// creating predefined data if file data.dat not exists
        /// </summary>
        public void CreateSomeDots()
        {
            Circle c = new Circle(10, 25, Color.Red, 8);
            

            _dots.Add(c);
  
        }

        /// <summary>
        /// Create Rectangle
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="color"></param>
        /// <param name="sidelength"></param>
        /// <returns></returns>
        public Rectangle CreateRectangle(int x, int y, Color color, int sizeOne, int sizeTwo)
        {
            Rectangle sq = new Rectangle(x, y, color, sizeOne, sizeTwo);
            return sq;
        }
        /// <summary>
        /// Create Circle
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="color"></param>
        /// <param name="radius"></param>
        /// <returns></returns>
        public Circle CreateCircle(int x, int y, Color color, int radius)
        {
            Circle c = new Circle(x, y, color, radius);
            return c;
        }
        /// <summary>
        /// Create Line
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="color"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public Line CreateLine(int x, int y, Color color, int length)
        {
            Line l = new Line(x, y, color, length );

            return l;
        }

        /// <summary>
        /// add dots in the list
        /// </summary>
        /// <param name="dotItem"></param>
        public void AddDots(Dot dotItem)
        {
            _dots.Add(dotItem);
            this.UpdateViews();
        }
        /// <summary>
        /// removing dot from the list
        /// </summary>
        /// <param name="index"></param>
        public void RemoveDot(int index)
        {
            _dots.RemoveAt(index);
            this.UpdateViews();
        }
        /// <summary>
        /// modify dot
        /// </summary>
        /// <param name="dotItem"></param>
        /// <param name="i"></param>
        public void ModifyDots(Dot dotItem, int i)
        {
            _dots[i] = dotItem;

            this.UpdateViews();
        }

        /// <summary>
        /// tell controller to update views
        /// </summary>
        public void UpdateViews()
        {
            _cont.UpdateViews();
        }

        /// <summary>
        /// serialization
        /// </summary>
        public void Serialize()
        {
            try
            {
               

                    FileStream strm = new FileStream(_fileName, FileMode.Create);
                    foreach (Dot d in _dots)
                    {
                       
                        _binFormatter.Serialize(strm, d);
                    }
                    strm.Close();
                
            }
            catch (Exception e)
            { }
        }
        
        /// <summary>
        /// do serialization every 2 seconds
        /// </summary>
        public void RunSerialization()
        {
            while (_isRunning)
            {
                this.Serialize();
                Thread.Sleep(2000);
            }

        }

        /// <summary>
        /// deserialization
        /// </summary>

        public void Deserialize()
        {

            _dots.Clear();
            FileInfo finfo = new FileInfo(_fileName);
            try
            {
                Stream strm = finfo.Open(FileMode.Open);

                while (strm.Position != strm.Length)
                {
                    _dots.Add(_binFormatter.Deserialize(strm) as Dot);
                }
                strm.Close();
                UpdateViews();
            }
            catch (Exception e)
            { }
        }

        /// <summary>
        ///start thread and run the method RumSerialization in the parallel thread
        /// </summary>
        public void ThreadWorking()
        {
            ThreadStart job = new ThreadStart(RunSerialization);
            _writeToBinary = new Thread(job);
            _writeToBinary.IsBackground = true;
            _writeToBinary.Start();

        }

        /// <summary>
        /// Manual stop thread
        /// </summary>
        public void ManualStopThread()
        {
            _isRunning = false;
            _writeToBinary.Join();
        }
    }
}
