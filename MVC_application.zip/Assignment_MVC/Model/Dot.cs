﻿//Created by Elena Shuvaeva 2.06.2016
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_MVC.Model
{
    [Serializable()]
    //abstract parent class 
    public abstract class Dot
    {
        public int X { get { return _dotX; } set { _dotX = value; } }
        public int Y { get { return _dotY; } set { _dotY = value; } }
        public Color Color { get { return _dotColor; }set { _dotColor = value; } }
        public virtual string ClassName { get;  }
        public virtual string Size { get; }
        protected int _dotX;
        protected int _dotY;
    
        protected Color _dotColor;
   //constructor for inheitance (we don't create an instance of this class because it's an abstract class)
        public Dot(int x, int y, Color color)
        {
            _dotX = x;
            _dotY = y;
            _dotColor = color;
        }

   //constructor for serialization
        public Dot() { }
  
     


    }
}
