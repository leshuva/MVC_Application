﻿//Created by Elena Shuvaeva 2.06.2016
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Assignment_MVC.Model
{
    [Serializable()]
    //subclass inherited from Dot
    public class Rectangle: Dot
    {
      
        public int SideOne{ get; set; }
        public int SideTwo { get; set; }
        public override string Size { get { return "Size of the sides:" + SideOne.ToString() + ";" + SideTwo.ToString(); } }
        public override string ClassName
        {
            get
            {
                return "Rectangle";
            }
        }
        #region Costructor
        public Rectangle(int x, int y, Color color,int sizeOne, int sizeTwo):base(x,y, color)
        {
            SideOne = sizeOne;
            SideTwo = sizeTwo;
        }
        #endregion
        /// <summary>
        /// Unique method
        /// </summary>
        /// <param name="g"></param>
        /// <param name="d"></param>
        public static void DrawRectangle(Graphics g, Dot d)
        {
            int x = d.X; 
            int y = d.Y;
            Color color = d.Color;

            Rectangle s = d as Rectangle;
            int size1 = s.SideOne;
            int size2 = s.SideTwo;
            Pen pen = new Pen(color, 3);
            g.DrawRectangle(pen, x, y, size1, size2);
        }
    }
}
