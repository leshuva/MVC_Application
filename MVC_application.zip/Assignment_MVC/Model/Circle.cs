﻿//Created by Elena Shuvaeva 2.06.2016
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_MVC.Model
{
    [Serializable()]
    //subclass inherited from Dot
    public class Circle:Dot
    {
    
        public int Diameter { get; set; }
        public override string Size { get { return "Diameter: "+ Diameter.ToString(); } }
        public override string ClassName
        {
            get
            {
                return "Circle";
            }

         }

        #region  Constructor
        public Circle (int x, int y,Color color,int diameter):base(x,y,color)
        {
            Diameter = diameter;
        }
        #endregion
        /// <summary>
        /// Unique method
        /// </summary>
        /// <param name="g"></param>
        /// <param name="d"></param>
        public static void DrawCircle(Graphics g, Dot d)
        {
            int x = d.X;
            int y = d.Y;
            Color color = d.Color;
            Circle circle = d as Circle;
            int diameter = circle.Diameter;
            Pen pen = new Pen(color, 3);
            g.DrawEllipse(pen, x, y,diameter,diameter);
        }


    }
}
