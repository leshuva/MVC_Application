﻿//Created by Elena Shuvaeva 2.06.2016
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_MVC
{
    /// <summary>
    /// inreface. All three views implement this interface
    /// </summary>
    public interface IView
    {
        void UpdateView();
    }
}
