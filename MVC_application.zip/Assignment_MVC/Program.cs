﻿using System;
using System.Collections.Generic;
//Created by Elena Shuvaeva 2.06.2016
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_MVC
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
            
        }
    }
}
