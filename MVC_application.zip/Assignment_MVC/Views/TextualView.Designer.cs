﻿namespace Assignment_MVC.Views
{
    partial class TextualView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.addSquareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlText = new System.Windows.Forms.Panel();
            this.btncolor = new System.Windows.Forms.Button();
            this.pictBox = new System.Windows.Forms.PictureBox();
            this.lblsize2 = new System.Windows.Forms.Label();
            this.txtsize2 = new System.Windows.Forms.TextBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.btnModify = new System.Windows.Forms.Button();
            this.lblShape = new System.Windows.Forms.Label();
            this.cmbShape = new System.Windows.Forms.ComboBox();
            this.btnADD = new System.Windows.Forms.Button();
            this.lblSize = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.txtY = new System.Windows.Forms.TextBox();
            this.txtX = new System.Windows.Forms.TextBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this._dGViewMain = new System.Windows.Forms.DataGridView();
            this.lblmainMenuMessage = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1.SuspendLayout();
            this.pnlText.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._dGViewMain)).BeginInit();
            this.SuspendLayout();
            // 
            // addSquareToolStripMenuItem
            // 
            this.addSquareToolStripMenuItem.Name = "addSquareToolStripMenuItem";
            this.addSquareToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.addSquareToolStripMenuItem.Text = "AddDot";
            this.addSquareToolStripMenuItem.Click += new System.EventHandler(this.addSquareToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSquareToolStripMenuItem,
            this.deleteRowToolStripMenuItem,
            this.updateToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(839, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.deleteRowToolStripMenuItem.Text = "DeleteRow";
            this.deleteRowToolStripMenuItem.Click += new System.EventHandler(this.deleteRowToolStripMenuItem_Click);
            // 
            // updateToolStripMenuItem
            // 
            this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            this.updateToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.updateToolStripMenuItem.Text = "Update";
            this.updateToolStripMenuItem.Click += new System.EventHandler(this.updateToolStripMenuItem_Click);
            // 
            // pnlText
            // 
            this.pnlText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlText.Controls.Add(this.btncolor);
            this.pnlText.Controls.Add(this.pictBox);
            this.pnlText.Controls.Add(this.lblsize2);
            this.pnlText.Controls.Add(this.txtsize2);
            this.pnlText.Controls.Add(this.lblMessage);
            this.pnlText.Controls.Add(this.btnModify);
            this.pnlText.Controls.Add(this.lblShape);
            this.pnlText.Controls.Add(this.cmbShape);
            this.pnlText.Controls.Add(this.btnADD);
            this.pnlText.Controls.Add(this.lblSize);
            this.pnlText.Controls.Add(this.lblY);
            this.pnlText.Controls.Add(this.lblX);
            this.pnlText.Controls.Add(this.txtSize);
            this.pnlText.Controls.Add(this.txtY);
            this.pnlText.Controls.Add(this.txtX);
            this.pnlText.Location = new System.Drawing.Point(12, 279);
            this.pnlText.Name = "pnlText";
            this.pnlText.Size = new System.Drawing.Size(816, 134);
            this.pnlText.TabIndex = 1;
            // 
            // btncolor
            // 
            this.btncolor.Location = new System.Drawing.Point(121, 22);
            this.btncolor.Name = "btncolor";
            this.btncolor.Size = new System.Drawing.Size(95, 23);
            this.btncolor.TabIndex = 17;
            this.btncolor.Text = "Choose color";
            this.btncolor.UseVisualStyleBackColor = true;
            this.btncolor.Click += new System.EventHandler(this.btncolor_Click);
            // 
            // pictBox
            // 
            this.pictBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictBox.Location = new System.Drawing.Point(239, 26);
            this.pictBox.Name = "pictBox";
            this.pictBox.Size = new System.Drawing.Size(58, 19);
            this.pictBox.TabIndex = 16;
            this.pictBox.TabStop = false;
            // 
            // lblsize2
            // 
            this.lblsize2.AutoSize = true;
            this.lblsize2.Location = new System.Drawing.Point(372, 58);
            this.lblsize2.Name = "lblsize2";
            this.lblsize2.Size = new System.Drawing.Size(0, 13);
            this.lblsize2.TabIndex = 15;
            // 
            // txtsize2
            // 
            this.txtsize2.Location = new System.Drawing.Point(366, 74);
            this.txtsize2.Name = "txtsize2";
            this.txtsize2.Size = new System.Drawing.Size(41, 20);
            this.txtsize2.TabIndex = 13;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(16, 110);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(0, 13);
            this.lblMessage.TabIndex = 7;
            // 
            // btnModify
            // 
            this.btnModify.Location = new System.Drawing.Point(3, 74);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(75, 23);
            this.btnModify.TabIndex = 11;
            this.btnModify.Text = "ModifyDot";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // lblShape
            // 
            this.lblShape.AutoSize = true;
            this.lblShape.Location = new System.Drawing.Point(19, 8);
            this.lblShape.Name = "lblShape";
            this.lblShape.Size = new System.Drawing.Size(38, 13);
            this.lblShape.TabIndex = 10;
            this.lblShape.Text = "Shape";
            // 
            // cmbShape
            // 
            this.cmbShape.FormattingEnabled = true;
            this.cmbShape.Location = new System.Drawing.Point(19, 26);
            this.cmbShape.Name = "cmbShape";
            this.cmbShape.Size = new System.Drawing.Size(85, 21);
            this.cmbShape.TabIndex = 9;
            // 
            // btnADD
            // 
            this.btnADD.Location = new System.Drawing.Point(104, 74);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(75, 23);
            this.btnADD.TabIndex = 8;
            this.btnADD.Text = "AddDot";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblSize
            // 
            this.lblSize.AutoSize = true;
            this.lblSize.Location = new System.Drawing.Point(303, 58);
            this.lblSize.Name = "lblSize";
            this.lblSize.Size = new System.Drawing.Size(27, 13);
            this.lblSize.TabIndex = 7;
            this.lblSize.Text = "Size";
            // 
            // lblY
            // 
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(372, 12);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(14, 13);
            this.lblY.TabIndex = 5;
            this.lblY.Text = "Y";
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(303, 12);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(14, 13);
            this.lblX.TabIndex = 4;
            this.lblX.Text = "X";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(303, 74);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(47, 20);
            this.txtSize.TabIndex = 3;
            // 
            // txtY
            // 
            this.txtY.Location = new System.Drawing.Point(366, 26);
            this.txtY.Name = "txtY";
            this.txtY.Size = new System.Drawing.Size(41, 20);
            this.txtY.TabIndex = 1;
            // 
            // txtX
            // 
            this.txtX.Location = new System.Drawing.Point(303, 26);
            this.txtX.Name = "txtX";
            this.txtX.Size = new System.Drawing.Size(47, 20);
            this.txtX.TabIndex = 0;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // _dGViewMain
            // 
            this._dGViewMain.AllowDrop = true;
            this._dGViewMain.AllowUserToOrderColumns = true;
            this._dGViewMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._dGViewMain.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this._dGViewMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dGViewMain.Location = new System.Drawing.Point(12, 50);
            this._dGViewMain.Name = "_dGViewMain";
            this._dGViewMain.ReadOnly = true;
            this._dGViewMain.Size = new System.Drawing.Size(813, 209);
            this._dGViewMain.TabIndex = 2;
            // 
            // lblmainMenuMessage
            // 
            this.lblmainMenuMessage.AutoSize = true;
            this.lblmainMenuMessage.Location = new System.Drawing.Point(31, 34);
            this.lblmainMenuMessage.Name = "lblmainMenuMessage";
            this.lblmainMenuMessage.Size = new System.Drawing.Size(0, 13);
            this.lblmainMenuMessage.TabIndex = 13;
            // 
            // TextualView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 432);
            this.Controls.Add(this.lblmainMenuMessage);
            this.Controls.Add(this._dGViewMain);
            this.Controls.Add(this.pnlText);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "TextualView";
            this.Text = "Textual";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlText.ResumeLayout(false);
            this.pnlText.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._dGViewMain)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addSquareToolStripMenuItem;
        private System.Windows.Forms.Panel pnlText;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.TextBox txtSize;
        private System.Windows.Forms.TextBox txtY;
        private System.Windows.Forms.TextBox txtX;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Label lblSize;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.Label lblShape;
        private System.Windows.Forms.ComboBox cmbShape;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
        public System.Windows.Forms.DataGridView _dGViewMain;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Label lblDotColor;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label lblmainMenuMessage;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.TextBox txtsize2;
        private System.Windows.Forms.Label lblsize2;
        private System.Windows.Forms.PictureBox pictBox;
        private System.Windows.Forms.Button btncolor;
    }
}