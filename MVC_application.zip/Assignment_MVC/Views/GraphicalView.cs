﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_MVC.Views
{
    public partial class GraphicalView : Form, IView
    {
        private Model.Model _model;
        private const int _staticWidth = 600;
        private const int _staticHeight = 300;

        bool _mousePressed = false;
        private Dot _draggedDot;
        int _currentIndex;

        #region Constructor
        public GraphicalView(Model.Model model)
        {
            _model = model;
            InitializeComponent();
            FormClosing += GraphicalView_FormClosing1;
            AllowDrop = true;

            MouseDown += GraphicalView_MouseDown;
            MouseUp += GraphicalView_MouseUp;
            this.MouseMove += GraphicalView_MouseMove;

        }
        #endregion

        /// <summary>
        /// moving the shape
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GraphicalView_MouseMove(object sender, MouseEventArgs e)
        {
            if (!_mousePressed || (_mousePressed && _draggedDot == null))
            {
                return;
            }

            _draggedDot.X = e.X;
            _draggedDot.Y = e.Y;
            _model.ModifyDots(_draggedDot, _currentIndex);

        }

        /// <summary>
        /// stop moving the shape
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void GraphicalView_MouseUp(object sender, MouseEventArgs e)
        {

            _mousePressed = false;
            _draggedDot = null;
        }

        /// <summary>
        /// choose the shape woth the mouse down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GraphicalView_MouseDown(object sender, MouseEventArgs e)
        {

            _mousePressed = true;

            int size = 5;

            List<Dot> dots = _model.Dots;
            for (int i = 0; i < dots.Count; i++)
            {
                Dot dot = dots[i];
                if (dot is Circle)
                {
                    var diameter = (dot as Circle).Diameter;

                    if ((e.X <= dot.X + diameter + size && e.X >= dot.X - size) &&
                      (e.Y >= dot.Y - size && e.Y <= dot.Y + diameter + size))
                    {
                        _draggedDot = dot;
                        _currentIndex = i;
                    }
                }

                if (dot is Line)
                {
                    var length = (dot as Line).Length;

                    if ((e.X <= dot.X + length + size && e.X >= dot.X - size) &&
                      (e.Y >= dot.Y - size && e.Y <= dot.Y + length + size))
                    {
                        _draggedDot = dot;
                        _currentIndex = i;
                    }
                }
                if (dot is Model.Rectangle)
                {
                    var sideX = (dot as Model.Rectangle).SideOne;
                    var sideY = (dot as Model.Rectangle).SideTwo;

                    if ((e.X <= dot.X + sideX + size && e.X >= dot.X - size) &&
                      (e.Y >= dot.Y - size && e.Y <= dot.Y + sideY + size))
                    {
                        _draggedDot = dot;
                        _currentIndex = i;
                    }
                }
            }


        }

        /// <summary>
        /// form close, the form is hidden
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GraphicalView_FormClosing1(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        /// <summary>
        /// update view-interface mothod
        /// </summary>
        public void UpdateView()
        {

            this.Refresh();

        }
        /// <summary>
        /// redraw the form
        /// </summary>
        /// <param name="e"></param>

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawDots(e.Graphics);

        }

        /// <summary>
        /// draw method. depending on the shape the unique method called
        /// </summary>
        /// <param name="g"></param>
        protected void DrawDots(Graphics g)
        {
            List<Dot> listDots = _model.Dots;

            foreach (Dot d in listDots)
            {
                if (d is Model.Rectangle)
                {
                    Model.Rectangle.DrawRectangle(g, d);
                }
                else if (d is Circle)
                {
                    Circle.DrawCircle(g, d);
                }
                else if (d is Line)
                {
                    Line.DrawLine(g, d);
                }
            }

        }


    }
}
