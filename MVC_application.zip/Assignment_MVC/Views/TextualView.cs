﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.Model;
using Assignment_MVC.MVC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_MVC.Views
{
    //displays textual view for the  dots and implements Iview interface
    public partial class TextualView : Form, IView
    {
        private string _rectangle = "Rectangle";
        private string _line = "Line";
        private string _cirle = "Circle";
        private Model.Model _model;
        private Color _color ;
        int _currentIndex = 0;
        private Dot _currentDot;
        #region Constructor
        public TextualView(Model.Model model)
        {
            this.Controls.Add(_dGViewMain);
            _model = model;
            InitializeComponent();
            InitializeDataGridView();

            pnlText.Visible = false;
            cmbShape.Items.Add(_cirle);
            cmbShape.Items.Add(_line);
            cmbShape.Items.Add(_rectangle);
            this.FormClosing += TextualView_FormClosing;
            cmbShape.SelectedValueChanged += CmbShape_SelectedValueChanged;
            deleteRowToolStripMenuItem.MouseHover += DeleteRowToolStripMenuItem_MouseHover;
            deleteRowToolStripMenuItem.MouseLeave += DeleteRowToolStripMenuItem_MouseLeave;

            _dGViewMain.SelectionChanged += _dGViewMain_SelectionChanged;

        }
        #endregion
        /// <summary>
        /// User chooses the cell in datagridview and combobox shows the shape of the chosen item
        /// </summary>

        private void _dGViewMain_SelectionChanged(object sender, EventArgs e)
        {

            _currentIndex = _dGViewMain.CurrentCell.RowIndex;
            if (_currentIndex > 0 && _currentIndex != _model.Dots.Count)
            {
                _currentDot = _model.Dots[_currentIndex];
                cmbShape.Text = _currentDot.ClassName;
            }
        }
        /// <summary>
        /// the hint for user , that he needs to select the whole row in order to delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void DeleteRowToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            lblmainMenuMessage.Visible = false;
        }

        private void DeleteRowToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            lblmainMenuMessage.Visible = true;
            lblmainMenuMessage.ForeColor = Color.Red;
            lblmainMenuMessage.Text = "Please choose the whole row to delete";

        }

        /// <summary>
        /// shows the names of controls depending on the chosen shape in the combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CmbShape_SelectedValueChanged(object sender, EventArgs e)
        {

            if (cmbShape.SelectedItem.Equals(_cirle))
            {

                lblSize.Text = "Diameter";
                lblsize2.Visible = false;
                txtsize2.Visible = false;


            }
            if (cmbShape.SelectedItem.Equals(_line))
            {

                lblSize.Text = "Length";
                lblsize2.Visible = false;
                txtsize2.Visible = false;



            }
            if (cmbShape.SelectedItem.Equals(_rectangle))
            {
                lblSize.Text = "Width";
                lblsize2.Visible = true;
                lblsize2.Text = "Height";
                txtsize2.Visible = true;


            }
        }


        /// <summary>
        /// event for closing the form. The form is not deleted, but hidden
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TextualView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }
        /// <summary>
        /// method that  interfaces implements
        /// </summary>
        public void UpdateView()
        {
            _dGViewMain.DataSource = null;
            _dGViewMain.DataSource = _model.Dots;

        }

        /// <summary>
        /// initialize datagridview
        /// </summary>
        private void InitializeDataGridView()
        {
            // Set up the DataGridView.
            _dGViewMain.Dock = DockStyle.Fill;

            // Automatically generate the DataGridView columns.
            _dGViewMain.AutoGenerateColumns = true;

            // Set up the data source.

            _dGViewMain.DataSource = _model.Dots;

            // Automatically resize the visible rows.
            _dGViewMain.AutoSizeRowsMode =
                DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;

            // Set the DataGridView control's border.
            _dGViewMain.BorderStyle = BorderStyle.Fixed3D;

            _dGViewMain.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            _dGViewMain.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }

        /// <summary>
        /// add dot menu tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void addSquareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            pnlText.Visible = true;
            pnlText.BringToFront();
            btnModify.Visible = false;
            btnADD.Visible = true;
            cmbShape.Visible = true;
            cmbShape.Enabled = true;

        }

        /// <summary>
        /// delete dot menu tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void deleteRowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in _dGViewMain.SelectedRows)
            {
                if (row.Index == -1)
                { return; }
                _model.RemoveDot(row.Index);

            }

        }

        /// <summary>
        /// validate input for rectangle
        /// </summary>
        /// <returns></returns>
        private bool ValidaRectangle()
        {
            int x;
            int y;
            int height;
            int width;
            if (!Int32.TryParse(txtX.Text, out x)
                ||
                (!Int32.TryParse(txtY.Text, out y))
                ||
                (!Int32.TryParse(txtSize.Text, out height))
                ||
                (!Int32.TryParse(txtsize2.Text, out width))
                              )
            {
                MessageBox.Show("please fill all the values and input integers for X, Y, Heigth and Width");
                return false;
            }

            else
            { return true; }
        }
        /// <summary>
        /// validate input for circle
        /// </summary>
        /// <returns></returns>
        private bool ValidateCircle()
        {
            int x;
            int y;
            int diameter;

            if (!Int32.TryParse(txtX.Text, out x)
                ||
                (!Int32.TryParse(txtY.Text, out y))
                ||
                (!Int32.TryParse(txtSize.Text, out diameter))
               
                )
            {
                MessageBox.Show("please fill all the fields and input integers for X, Y, Diameter");
                return false;
            }

            else
            { return true; }
        }
        /// <summary>
        /// validate input line
        /// </summary>
        /// <returns></returns>
        private bool ValidateLine()
        {
            int x;
            int y;
            int length;

            if (!Int32.TryParse(txtX.Text, out x)
                ||
                (!Int32.TryParse(txtY.Text, out y))
                ||
                (!Int32.TryParse(txtSize.Text, out length))
                
                )
            {
                MessageBox.Show("please fill all the fields and input integers for X, Y, Length");
                return false;
            }

            else
            { return true; }
        }

        /// <summary>
        /// button add dot
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            lblMessage.Visible = false;
            if (txtX.Text.Length != 0 && txtY.Text.Length != 0 && txtSize.Text.Length != 0 && (cmbShape.SelectedItem != null))
            {

                if (cmbShape.SelectedItem.Equals(_rectangle))
                {
                    if (ValidaRectangle())
                    {
                        Model.Rectangle s = _model.CreateRectangle(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text), _color, Convert.ToInt32(txtSize.Text), Convert.ToInt32(txtsize2.Text));
                        _model.AddDots(s);
                    }
                    else { return; }

                }
                if (cmbShape.SelectedItem.Equals(_cirle))
                {

                    txtsize2.Visible = false;
                    if (ValidateCircle())
                    {
                        Circle c = _model.CreateCircle(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text), _color, Convert.ToInt32(txtSize.Text));
                        _model.AddDots(c);
                    }
                    else { return; }
                }
                if (cmbShape.SelectedItem.Equals(_line))
                {
                    if (ValidateLine())
                    {
                        Line l = _model.CreateLine(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text), _color, Convert.ToInt32(txtSize.Text));
                        _model.AddDots(l);
                    }
                    else { return; }
                }
                pnlText.Hide();
            }
            else

            {
                lblMessage.Visible = true;
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = "Please, make sure, that all the textboxes are filled and the shape is chosen";

            }
        }

        /// <summary>
        /// update dot menu tab
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {

            pnlText.Enabled = true;
            pnlText.Visible = true;
            pnlText.BringToFront();
            cmbShape.Visible = true;
            cmbShape.Enabled = false;
            _currentIndex = _dGViewMain.CurrentCell.RowIndex;
            _currentDot = _model.Dots[_currentIndex];
            cmbShape.Text = _currentDot.ClassName;
            txtX.Text = _currentDot.X.ToString();
            txtY.Text = _currentDot.Y.ToString();
            pictBox.BackColor = _currentDot.Color;

            //check what shape is dot
            if (_currentDot is Model.Rectangle)
            {
                txtSize.Text = (_currentDot as Model.Rectangle).SideOne.ToString();
                txtsize2.Text = (_currentDot as Model.Rectangle).SideTwo.ToString();
            }
            if (_currentDot is Circle)
            {
                txtSize.Text = (_currentDot as Model.Circle).Diameter.ToString();
            }
            if(_currentDot is Line)
            {
                txtSize.Text = (_currentDot as Model.Line).Length.ToString();
            }
            btnADD.Visible = false;
            btnModify.Visible = true;



        }


        /// <summary>
        /// Do modify for each properties of the sub class
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnModify_Click(object sender, EventArgs e)
        {

            int i = _dGViewMain.CurrentCell.RowIndex;
            Dot d = _model.Dots[i];
            if (cmbShape.SelectedItem.Equals(_rectangle))
            {
                Model.Rectangle s = d as Model.Rectangle;

                if (ValidaRectangle())
                {

                    d.X = Convert.ToInt32(txtX.Text);
                    d.Y = Convert.ToInt32(txtY.Text);
                    d.Color = pictBox.BackColor;
                    s.SideOne = Convert.ToInt32(txtSize.Text);
                    s.SideTwo = Convert.ToInt32(txtsize2.Text);

                }
                else { return; }
            }

            if (cmbShape.SelectedItem.Equals(_cirle))
            {
                Model.Circle s = d as Model.Circle;

                if (ValidateCircle())
                {

                    d.X = Convert.ToInt32(txtX.Text);
                    d.Y = Convert.ToInt32(txtY.Text);
                    d.Color = pictBox.BackColor;
                    s.Diameter = Convert.ToInt32(txtSize.Text);
                  

                }
                else { return; }
            }
            if (cmbShape.SelectedItem.Equals(_line))
            {
                Model.Line l = d as Model.Line;

                if (ValidateLine())
                {

                    d.X = Convert.ToInt32(txtX.Text);
                    d.Y = Convert.ToInt32(txtY.Text);
                    d.Color = pictBox.BackColor;
                    l.Length = Convert.ToInt32(txtSize.Text);


                }
              else  { return; }
            }

            _model.ModifyDots(d, i);
            btnModify.Visible = false;
            pnlText.Hide();


        }

        
        /// <summary>
        /// button for displaying the color dialog
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btncolor_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            _color = colorDialog1.Color;
            pictBox.BackColor = _color;


        }
    }

}
