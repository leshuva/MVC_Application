﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_MVC.Views
{
    public partial class FilteredView : Form, IView
    {
        private Model.Model _model;
        enum Filter { All,Square, Circle, Line };
        private Filter _filter = Filter.All;
        #region Constructor
        public FilteredView(Model.Model model)
        {
            _model = model;
            InitializeComponent();
            FormClosing += GraphicalView_FormClosing1;
            AllowDrop = true;
       
        }
        #endregion

        /// <summary>
        /// close form-form hidden
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        protected void GraphicalView_FormClosing1(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }

        /// <summary>
        /// update view-interface's method
        /// </summary>
        public void UpdateView()
        {
            this.Refresh();
            
         }

        /// <summary>
        /// redraw the form
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawDots(e.Graphics);

       }
        /// <summary>
        /// draw method. depending on the filter shape the unique method called
        /// </summary>
        /// <param name="g"></param>
        protected void DrawDots(Graphics g)
        {
            List<Dot> listDots = _model.Dots;

            foreach (Dot d in listDots)
            {
                if (d is Model.Rectangle && (_filter == Filter.Square || _filter == Filter.All))
                {
                    Model.Rectangle.DrawRectangle(g, d);
                }
                else if (d is Circle && (_filter == Filter.Circle || _filter == Filter.All))
                {
                    Circle.DrawCircle(g, d);
                }
                else if (d is Line && (_filter == Filter.Line || _filter == Filter.All))
                {
                    Line.DrawLine(g, d);
                }
            }

        }

        /// <summary>
        /// filter -rectangle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void rectanglesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _filter = Filter.Square;
            Refresh();
        }
        /// <summary>
        /// filter-lines
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void linesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _filter = Filter.Line;
            Refresh();
        }

        /// <summary>
        /// filter-circles
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void circlesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _filter = Filter.Circle;
            Refresh();
        }

        /// <summary>
        /// filter-all shapes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _filter = Filter.All;
            Refresh();
        }
    }
}
