﻿//Created by Elena Shuvaeva 2.06.2016
using Assignment_MVC.MVC;
using Assignment_MVC.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_MVC
{
    public partial class MainForm : Form
    {

        private TextualView _tv;
        private GraphicalView _gv;
        private FilteredView _rof;
        private Controller _cont;
        private Model.Model _model;
        public Model.Model Model { get { return _model; } }

        #region Costructor
        public MainForm()
        {
            InitializeComponent();
           _cont = new Controller();
            _model = new Model.Model(_cont);
            _tv = new TextualView(_model);
            _gv = new GraphicalView(_model);
            _rof= new FilteredView(_model);
            _cont.AddView(_tv);
            _cont.AddView(_gv);
            _cont.AddView(_rof);
          
            FormClosing += MainForm_FormClosing;
         }
        #endregion
        /// <summary>
        /// main form close
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _model._isRunning = false;
          
        }
        /// <summary>
        /// textual view show
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _tv.Show();
           
        }
        /// <summary>
        /// graphical view show
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void graphicalToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
           _gv.Show();
                       
        }
        /// <summary>
        /// filtered view show
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void readOnlyFilteredToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _rof.Show();
          
        }

    

     
    }
}
